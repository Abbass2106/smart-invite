import React from 'react'

const ViewGuests = () => {
  return (
    <div>
      
    </div>
  )
}

export default ViewGuests
