import React from 'react'
import { useLocation } from 'react-router-dom';


const UploadGuests = () => {
  const location = useLocation();
  const eventID = location.state?.eventID || "No Event ID";
  return (
    <div>
      <div className="header">
        <h1>Upload Guests</h1>
      </div>

      <p>
        Select event ID: {eventID}
      </p>

      <div className="get-file">
        <p>Upload CSV file :</p>
        <input type="file" accept=".csv" />
      </div>

      <button type='submit'>Upload</button>

    </div>
  )
}

export default UploadGuests
